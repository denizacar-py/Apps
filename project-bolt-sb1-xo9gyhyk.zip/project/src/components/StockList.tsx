import React from 'react';
import { Trash2, Pencil } from 'lucide-react';
import { StockItem } from '../types/stock';
import { formatCurrency } from '../utils/calculations';

interface StockListProps {
  items: StockItem[];
  onDelete: (id: string) => void;
  onEdit: (id: string) => void;
}

export function StockList({ items, onDelete, onEdit }: StockListProps) {
  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div
          key={item.id}
          className="bg-white rounded-lg shadow-md p-4 flex justify-between items-start"
        >
          <div className="flex-1">
            <h3 className="text-lg font-semibold">{item.name}</h3>
            <p className="text-gray-600">{item.description}</p>
            <div className="mt-2 grid grid-cols-2 gap-4">
              <span className="text-sm">
                Amount: <strong>{item.amount}</strong>
              </span>
              <span className="text-sm">
                Cost: <strong>{formatCurrency(item.costPrice, item.currency)}</strong>
              </span>
              <span className="text-sm">
                Price: <strong>{formatCurrency(item.sellingPrice, item.currency)}</strong>
              </span>
              <span className="text-sm">
                Profit/Item: <strong className="text-green-600">
                  {formatCurrency(item.sellingPrice - item.costPrice, item.currency)}
                </strong>
              </span>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onEdit(item.id)}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
            >
              <Pencil size={20} />
            </button>
            <button
              onClick={() => onDelete(item.id)}
              className="p-2 text-red-600 hover:bg-red-50 rounded-full transition-colors"
            >
              <Trash2 size={20} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}