import React, { useState } from 'react';
import { StockItem } from '../types/stock';
import { X } from 'lucide-react';
import { FormField } from './common/FormField';
import { CurrencySelect } from './common/CurrencySelect';
import { inputStyles, buttonStyles } from '../styles/common';

interface EditStockFormProps {
  item: StockItem;
  onSave: (id: string, updatedItem: Omit<StockItem, 'id'>) => void;
  onCancel: () => void;
}

export function EditStockForm({ item, onSave, onCancel }: EditStockFormProps) {
  const [formData, setFormData] = useState({
    name: item.name,
    amount: item.amount,
    price: item.price,
    currency: item.currency,
    description: item.description,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(item.id, formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Edit Item</h3>
        <button
          type="button"
          onClick={onCancel}
          className="p-1 hover:bg-gray-100 rounded-full"
        >
          <X size={20} />
        </button>
      </div>

      <FormField id="edit-name" label="Name">
        <input
          type="text"
          id="edit-name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className={inputStyles}
          required
        />
      </FormField>

      <div className="grid grid-cols-2 gap-4">
        <FormField id="edit-amount" label="Amount">
          <input
            type="number"
            id="edit-amount"
            min="0"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
            className={inputStyles}
            required
          />
        </FormField>

        <FormField id="edit-price" label="Price">
          <input
            type="number"
            id="edit-price"
            min="0"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
            className={inputStyles}
            required
          />
        </FormField>
      </div>

      <FormField id="edit-currency" label="Currency">
        <CurrencySelect
          id="edit-currency"
          value={formData.currency}
          onChange={(value) => setFormData({ ...formData, currency: value })}
        />
      </FormField>

      <FormField id="edit-description" label="Description">
        <textarea
          id="edit-description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className={inputStyles}
          rows={3}
          required
        />
      </FormField>

      <div className="flex gap-3">
        <button
          type="submit"
          className={buttonStyles.primary + " flex-1"}
        >
          Save Changes
        </button>
        <button
          type="button"
          onClick={onCancel}
          className={buttonStyles.secondary + " flex-1"}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}