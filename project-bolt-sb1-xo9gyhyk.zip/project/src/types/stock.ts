export interface StockItem {
  id: string;
  name: string;
  amount: number;
  costPrice: number;
  sellingPrice: number;
  currency: string;
  description: string;
}