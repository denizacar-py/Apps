import React from 'react';
import { FormField } from '../common/FormField';
import { inputStyles } from '../../styles/common';

interface PriceInputsProps {
  costPrice: number;
  sellingPrice: number;
  onCostPriceChange: (value: number) => void;
  onSellingPriceChange: (value: number) => void;
}

export function PriceInputs({ 
  costPrice, 
  sellingPrice, 
  onCostPriceChange, 
  onSellingPriceChange 
}: PriceInputsProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <FormField id="cost-price" label="Cost Price">
        <input
          type="number"
          id="cost-price"
          min="0"
          step="0.01"
          value={costPrice}
          onChange={(e) => onCostPriceChange(Number(e.target.value))}
          className={inputStyles}
          required
        />
      </FormField>

      <FormField id="selling-price" label="Selling Price">
        <input
          type="number"
          id="selling-price"
          min="0"
          step="0.01"
          value={sellingPrice}
          onChange={(e) => onSellingPriceChange(Number(e.target.value))}
          className={inputStyles}
          required
        />
      </FormField>
    </div>
  );
}