import React, { useState } from 'react';
import { StockItem } from '../types/stock';
import { FormField } from './common/FormField';
import { CurrencySelect } from './common/CurrencySelect';
import { PriceInputs } from './forms/PriceInputs';
import { inputStyles, buttonStyles } from '../styles/common';

interface AddStockFormProps {
  onAdd: (item: Omit<StockItem, 'id'>) => void;
}

export function AddStockForm({ onAdd }: AddStockFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    amount: 0,
    costPrice: 0,
    sellingPrice: 0,
    currency: 'USD',
    description: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setFormData({
      name: '',
      amount: 0,
      costPrice: 0,
      sellingPrice: 0,
      currency: 'USD',
      description: '',
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-md">
      <FormField id="name" label="Name">
        <input
          type="text"
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className={inputStyles}
          required
        />
      </FormField>

      <FormField id="amount" label="Amount">
        <input
          type="number"
          id="amount"
          min="0"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
          className={inputStyles}
          required
        />
      </FormField>

      <PriceInputs
        costPrice={formData.costPrice}
        sellingPrice={formData.sellingPrice}
        onCostPriceChange={(value) => setFormData({ ...formData, costPrice: value })}
        onSellingPriceChange={(value) => setFormData({ ...formData, sellingPrice: value })}
      />

      <FormField id="currency" label="Currency">
        <CurrencySelect
          id="currency"
          value={formData.currency}
          onChange={(value) => setFormData({ ...formData, currency: value })}
        />
      </FormField>

      <FormField id="description" label="Description">
        <textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className={inputStyles}
          rows={3}
          required
        />
      </FormField>

      <button
        type="submit"
        className={buttonStyles.primary + " w-full"}
      >
        Add Stock Item
      </button>
    </form>
  );
}