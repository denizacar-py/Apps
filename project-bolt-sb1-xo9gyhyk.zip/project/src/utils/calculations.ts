export function calculateTotalCost(amount: number, price: number): number {
  return amount * price;
}

export function calculateProfit(costPrice: number, sellingPrice: number, amount: number): number {
  const totalCost = costPrice * amount;
  const totalRevenue = sellingPrice * amount;
  return totalRevenue - totalCost;
}

export function formatCurrency(amount: number, currency: string): string {
  return new Intl.NumberFormat('en-US', { 
    style: 'currency', 
    currency: currency 
  }).format(amount);
}