import React, { useState, useEffect } from 'react';
import { StockList } from './components/StockList';
import { AddStockForm } from './components/AddStockForm';
import { EditStockForm } from './components/EditStockForm';
import { StockStats } from './components/StockStats';
import { StockItem } from './types/stock';
import { Boxes } from 'lucide-react';
import { saveStocks, loadStocks } from './utils/storage';

export default function App() {
  const [stocks, setStocks] = useState<StockItem[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Load stocks from localStorage on initial render
  useEffect(() => {
    const savedStocks = loadStocks();
    setStocks(savedStocks);
  }, []);

  const handleAddStock = (newItem: Omit<StockItem, 'id'>) => {
    const item: StockItem = {
      ...newItem,
      id: crypto.randomUUID(),
    };
    const updatedStocks = [...stocks, item];
    setStocks(updatedStocks);
    saveStocks(updatedStocks);
  };

  const handleDeleteStock = (id: string) => {
    const updatedStocks = stocks.filter(item => item.id !== id);
    setStocks(updatedStocks);
    saveStocks(updatedStocks);
  };

  const handleEditStock = (id: string, updatedItem: Omit<StockItem, 'id'>) => {
    const updatedStocks = stocks.map(item => 
      item.id === id ? { ...updatedItem, id } : item
    );
    setStocks(updatedStocks);
    saveStocks(updatedStocks);
    setEditingId(null);
  };

  const editingItem = editingId ? stocks.find(item => item.id === editingId) : null;

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto py-8 px-4">
        <div className="flex items-center gap-3 mb-8">
          <Boxes className="text-blue-600" size={32} />
          <h1 className="text-3xl font-bold text-gray-900">Stock Management</h1>
        </div>

        <StockStats items={stocks} />

        <div className="grid gap-8 md:grid-cols-[2fr,3fr]">
          <div>
            <h2 className="text-xl font-semibold mb-4">
              {editingId ? 'Edit Stock Item' : 'Add New Stock'}
            </h2>
            {editingItem ? (
              <EditStockForm
                item={editingItem}
                onSave={handleEditStock}
                onCancel={() => setEditingId(null)}
              />
            ) : (
              <AddStockForm onAdd={handleAddStock} />
            )}
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Stock Items</h2>
            {stocks.length === 0 ? (
              <div className="bg-white rounded-lg shadow-md p-8 text-center text-gray-500">
                No stock items yet. Add your first item!
              </div>
            ) : (
              <StockList
                items={stocks}
                onDelete={handleDeleteStock}
                onEdit={setEditingId}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}