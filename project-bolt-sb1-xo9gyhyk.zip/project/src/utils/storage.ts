const STORAGE_KEY = 'stock-management-data';

export function saveStocks(stocks: any[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stocks));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
}

export function loadStocks(): any[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error loading from localStorage:', error);
    return [];
  }
}