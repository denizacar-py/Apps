import React from 'react';
import { TrendingUp, DollarSign, Package, PiggyBank } from 'lucide-react';
import { StockItem } from '../types/stock';
import { calculateTotalCost, calculateProfit, formatCurrency } from '../utils/calculations';

interface StockStatsProps {
  items: StockItem[];
}

export function StockStats({ items }: StockStatsProps) {
  const totalItems = items.reduce((sum, item) => sum + item.amount, 0);
  const totalCost = items.reduce((sum, item) => 
    sum + (item.costPrice * item.amount), 0
  );
  const totalProfit = items.reduce((sum, item) => 
    sum + calculateProfit(item.costPrice, item.sellingPrice, item.amount), 0
  );

  const stats = [
    {
      label: 'Total Items',
      value: totalItems,
      icon: Package,
      color: 'text-blue-600',
    },
    {
      label: 'Total Cost',
      value: formatCurrency(totalCost, 'USD'),
      icon: DollarSign,
      color: 'text-red-600',
    },
    {
      label: 'Potential Profit',
      value: formatCurrency(totalProfit, 'USD'),
      icon: PiggyBank,
      color: 'text-green-600',
    },
    {
      label: 'Avg. Profit Margin',
      value: totalCost > 0 
        ? `${((totalProfit / totalCost) * 100).toFixed(1)}%`
        : '0%',
      icon: TrendingUp,
      color: 'text-purple-600',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      {stats.map((stat) => (
        <div key={stat.label} className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center gap-3">
            <div className={`${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">{stat.label}</p>
              <p className="text-xl font-semibold">{stat.value}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}